import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import Sitemap from 'vite-plugin-sitemap';
import { createHtmlPlugin } from 'vite-plugin-html';
import path from 'path';

// Define your application routes here. This array is used by vite-ssg to
// prerender each route. Add entries like { path: '/about', name: 'About' }.
const routes = [
  { path: '/', name: 'Home' }
];

export default defineConfig({
  plugins: [
    react(),
    Sitemap({
      baseUrl: 'https://example.com',
      routes,
      generateRobotsTxt: false // Desactivado porque ya lo generamos manualmente en public/
    }),
    createHtmlPlugin({
      minify: true,
      inject: {
        data: {
          title: 'Default Title',
          description: 'Default Description'
        }
      }
    })
  ],
  resolve: {
    alias: [
      // 1. ARREGLO PARA IMPORTS CON VERSIÓN (ej: 'sonner@2.0.3' -> 'sonner')
      { 
        find: /^([a-zA-Z0-9@\/\-_]+)@\d+\.\d+\.\d+$/, 
        replacement: '$1' 
      },
      
      // 2. ARREGLO PARA IMÁGENES DE FIGMA (ej: "figma:asset/abc.png" -> "/src/assets/abc.png")
      { 
        find: /^figma:asset\/(.*)/, 
        replacement: '/src/assets/$1' 
      },
      
      // 3. Alias estándar
      { find: '@', replacement: '/src' }
    ]
  },
  // Corrección para SSR: Evitar error "Named export not found" con librerías CJS
  ssr: {
    noExternal: ['react-helmet-async']
  }
});
