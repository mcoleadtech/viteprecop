import { Helmet } from 'react-helmet-async';

export interface SeoProps {
  title: string;
  description: string;
  canonical: string;
  image?: string;
  schemaMarkup?: Record<string, any>;
}

/**
 * Seo component sets up meta tags, social cards and structured data on a
 * per-page basis using react-helmet-async. Pass whatever props you
 * need to customise the metadata for each route.
 */
export const SEO = ({ title, description, canonical, image, schemaMarkup }: SeoProps) => (
  <Helmet>
    <title>{title}</title>
    <meta name="description" content={description} />
    <link rel="canonical" href={canonical} />
    <meta property="og:title" content={title} />
    <meta property="og:description" content={description} />
    {image && <meta property="og:image" content={image} />} 
    <meta name="twitter:title" content={title} />
    <meta name="twitter:description" content={description} />
    {image && <meta name="twitter:image" content={image} />} 
    {schemaMarkup && (
      <script type="application/ld+json">
        {JSON.stringify(schemaMarkup)}
      </script>
    )}
  </Helmet>
);

// Mantenemos también el default export por compatibilidad si algún otro archivo lo usa así.
export default SEO;
