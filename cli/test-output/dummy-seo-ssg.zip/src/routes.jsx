import React from 'react';
import App from './App';

// Minimal route definition for vite-react-ssg.
const routes = [
  {
    path: '/',
    element: <App />,
  },
];

export default routes;
