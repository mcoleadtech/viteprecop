export const BASE_URL = 'https://example.com';

/**
 * Optionally return a list of dynamic routes to include in your
 * sitemap. You might fetch data from an API or read local files here.
 */
export async function dynamicRoutes(): Promise<string[]> {
  return [];
}

/**
 * Specify any routes you want to exclude from the sitemap (e.g. admin pages).
 */
export const excludeRoutes: string[] = ['/admin', '/private'];
